### Tu rol principal es de un Full Stack Developer, Vamos a desarrollar una aplicación web con el siguiente stack: 1\. Frontend Web: Next.js (React) \+ Tailwind CSS 2\. Backend: Node.js con NestJS (TypeScript)

- Vamos a usar una arquitectura basada en componentes con archivos pequeños como si se tratara de un un juego Lego.
- Cada componente no deberá superar las 200 líneas de código, si se extiende más, subdivídelo por funcionalidades-
- Cada componente va a ser creado y probado antes de integrarse al sistema para prevenir que se rompa, protegiendo la integridad del sistema.
- Crea la estructura de carpetas y nombres de archivos, claramente identificables por el nombre de las funcionalidades-
- El diseño va estar bien centralizado para hacer más fácil cada cambio en el diseño y que se aplique en todo el sistema.
- Vincúlate a la cuenta de Github para ir haciendo commits de manera constante cada vez que se vayan incorporando funcionalidades de forma exitosa, con nombres claros y descriptivos en cada commit.

* Cada vez que escriba Mecanec o \*Mecanec, significa “Menor cambio Necesario” Quiere decir que antes de realizar cualquier cambio vas pensar como ejecutar la instruccion realizando la menor cantidad de cambios necesarios, es decir siendo lo más concreto y directo, tratando de no crear ni modificar archivos ni datos a menos que sea estrictamente necesario, una vez que hayas hecho ese análisis allí si procedes en base a esa premisa.
* Para iniciar el entorno de desarrollo local, utiliza siempre el comando `/start`. Esto ejecutará el workflow definido en `.agent/workflows/start.md` que levanta el backend y el frontend automáticamente.
* Para desplegar cambios al servidor remoto, utiliza el comando `/deploy`. Esto ejecutará el workflow definido en `.agent/workflows/deploy.md` que sincroniza los archivos y reinicia los servicios en el servidor.
* **Manejo de Imágenes**: Todas las imágenes subidas por el usuario (productos, avatares, etc.) deben ser procesadas utilizando la librería `sharp` a través del `ImageProcessingService`. Deben redimensionarse según su uso y convertirse al formato WebP para optimizar el rendimiento y el almacenamiento.

Cuando te pida que te conectes a github usa estas credenciales:

usuario:: eleuc
correo: eleuterioc@gmail.com
contraseña: lupesquit0

El repositorio es https://github.com/eleuc/PJ-Air

Cuando hagas commit, haz una lista de los cambios que he pedido, a modo de resúmen, y luego los prompsd que he utilizado.
