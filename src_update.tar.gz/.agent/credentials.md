# Credenciales de Servidor - PJ-Air

| Host          | Usuario | IP            | Puerto | Pass             |
| ------------- | ------- | ------------- | ------ | ---------------- |
| VPS Namecheap | root    | 187.124.67.53 | 22     | o7BR&vX+F2;wqYye |

---

**Nota**: Estas credenciales se utilizan para los procesos de `/deploy` automáticos.
