---
description: Sincroniza los cambios locales con el servidor remoto y reinicia los servicios
---
// turbo-all
// turbo-all
1. Empaquetar y Sincronizar cambios (Frontend y Backend)
   - Comando: `tar -czf src_update.tar.gz frontend/app frontend/components frontend/lib frontend/context frontend/hooks frontend/scripts frontend/public backend/src backend/package.json frontend/package.json ecosystem.config.js .agent`
   - Comando: `scp -o StrictHostKeyChecking=no src_update.tar.gz root@187.124.67.53:/var/www/`

2. Extraer y Construir en el servidor
   - Comando: `ssh -o StrictHostKeyChecking=no root@187.124.67.53 "cd /var/www && tar -xzf src_update.tar.gz && cd frontend && npm run build"`
   - Comando: `ssh -o StrictHostKeyChecking=no root@187.124.67.53 "cd /var/www/backend && npm run build"`

3. Reiniciar procesos PM2
   - Comando: `ssh -o StrictHostKeyChecking=no root@187.124.67.53 "pm2 restart all"`

