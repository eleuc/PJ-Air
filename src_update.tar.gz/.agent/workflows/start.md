---
description: Inicia el entorno de desarrollo local (backend y frontend)
---
// turbo-all
1. Limpiar procesos anteriores (Evita errores de puerto ocupado)
   - Comando: `powershell -Command "Stop-Process -Id (Get-NetTCPConnection -LocalPort 3001 -ErrorAction SilentlyContinue).OwningProcess -Force -ErrorAction SilentlyContinue"`

2. Iniciar el servidor del backend
   - Directorio: `c:\Users\USUARIO\Documents\Antigravity\backend`
   - Comando: `npm run start:dev`

3. Iniciar el servidor del frontend
   - Directorio: `c:\Users\USUARIO\Documents\Antigravity\frontend`
   - Comando: `npm run dev`

