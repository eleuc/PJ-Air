const { Client } = require('ssh2');

const config = {
    host: '187.124.67.53',
    port: 22,
    username: 'root',
    password: 'o7BR&vX+F2;wqYye'
};

const conn = new Client();
conn.on('ready', () => {
    console.log('SSH Ready');
    
    // Read the backup JSON and query the database
    const script = `
        cd /var/www/pj-air/backend && node -e "
            const fs = require('fs');
            const sqlite3 = require('sqlite3');
            const crypto = require('crypto');
            const bcrypt = require('bcryptjs');

            const backup = JSON.parse(fs.readFileSync('/var/www/pj-air/users_password_backup.json', 'utf8'));
            const db = new sqlite3.Database('/var/www/pj-air/database.sqlite');

            const verifyPBKDF2 = (p, sv) => {
                const parts = sv.split(':');
                if (parts.length !== 2) return false;
                const [s, h] = parts;
                return crypto.pbkdf2Sync(p, s, 1000, 64, 'sha512').toString('hex') === h;
            };

            const verifyBcrypt = (p, sv) => {
                try {
                    return bcrypt.compareSync(p, sv.startsWith('$2y$') ? sv.replace(/^\\$2y\\$/, '$2a$') : sv);
                } catch(e) {
                    return false;
                }
            };

            db.all('SELECT id, email, password FROM users', (err, rows) => {
                if (err) {
                    console.error(err);
                    process.exit(1);
                }

                console.log('=== PASSWORD AUDIT REPORT ===');
                let successful = 0;
                let failed = 0;

                for (const row of rows) {
                    const plain = backup[row.id];
                    if (!plain) {
                        // User not in backup list (could be new or test user)
                        console.log('User not in backup list:', row.email, '(Hash:', row.password.substring(0, 15) + '...)');
                        continue;
                    }

                    let match = false;
                    if (row.password.includes(':')) {
                        match = verifyPBKDF2(plain, row.password);
                    } else if (row.password.startsWith('$2')) {
                        match = verifyBcrypt(plain, row.password);
                    } else {
                        match = row.password === plain;
                    }

                    if (match) {
                        successful++;
                    } else {
                        failed++;
                        console.log('❌ MISMATCH DETECTED:');
                        console.log('  Email:', row.email);
                        console.log('  Plaintext password in backup:', plain);
                        console.log('  Hash in DB:', row.password);
                    }
                }

                console.log('\\nAudit complete. Matches: ' + successful + ', Mismatches: ' + failed);
                db.close();
            });
        "
    `;

    conn.exec(script, (err, stream) => {
        if (err) throw err;
        let out = '';
        stream.on('close', () => {
            console.log(out);
            conn.end();
        }).on('data', d => out += d.toString()).stderr.on('data', d => console.error('STDERR:', d.toString()));
    });
}).connect(config);
