const { Client } = require('ssh2');

const config = {
    host: '187.124.67.53',
    port: 22,
    username: 'root',
    password: 'o7BR&vX+F2;wqYye'
};

const conn = new Client();
conn.on('ready', () => {
    console.log('SSH Ready');
    conn.exec('cat /var/www/pj-air/users_password_backup.json', (err, stream) => {
        if (err) throw err;
        let out = '';
        stream.on('close', () => {
            console.log(out);
            conn.end();
        }).on('data', d => out += d.toString());
    });
}).connect(config);
