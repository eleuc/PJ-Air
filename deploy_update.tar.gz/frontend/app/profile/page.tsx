'use client';

import React, { useState, useEffect } from 'react';
import Navbar from '@/components/layout/Navbar';
import { User, MapPin, Mail, Phone, BadgeCheck, Loader2, Save, Plus, Trash2 } from 'lucide-react';
import { useAuth } from '@/context/AuthContext';
import { api } from '@/lib/api';
import { useRouter } from 'next/navigation';
import { useLanguage } from '@/context/LanguageContext';
import { API_URL } from '@/lib/config';

export default function ProfilePage() {
    const { user, isLoading: isAuthLoading } = useAuth();
    const router = useRouter();
    const { t, locale } = useLanguage();
    const [isLoading, setIsLoading] = useState(true);
    const [isSaving, setIsSaving] = useState(false);
    const [profile, setProfile] = useState<any>(null);
    const [addresses, setAddresses] = useState<any[]>([]);
    const [formData, setFormData] = useState({
        full_name: '',
        username: '',
        phone: ''
    });
    const [passwordData, setPasswordData] = useState({
        currentPassword: '',
        newPassword: '',
        confirmPassword: ''
    });
    const [message, setMessage] = useState({ type: '', text: '' });
    const [passwordMessage, setPasswordMessage] = useState({ type: '', text: '' });
    const [isChangingPassword, setIsChangingPassword] = useState(false);

    const [isUploading, setIsUploading] = useState(false);

    useEffect(() => {
        if (isAuthLoading) return;
        
        if (!user) {
            router.push('/auth/login');
            return;
        }

        const fetchUserData = async () => {
            try {
                const userData = await api.get(`/users/${user.id}`) as any;
                setProfile(userData.profile);
                setAddresses(userData.addresses || []);
                setFormData({
                    full_name: userData.profile?.full_name || '',
                    username: userData.profile?.username || '',
                    phone: userData.profile?.phone || ''
                });
            } catch (err) {
                console.error('Error fetching user data:', err);
            } finally {
                setIsLoading(false);
            }
        };

        fetchUserData();
    }, [user, isAuthLoading, router]);

    const handleAvatarUpload = async (e: React.ChangeEvent<HTMLInputElement>) => {
        const file = e.target.files?.[0];
        if (!file || !user) return;

        setIsUploading(true);
        const uploadData = new FormData();
        uploadData.append('file', file);

        try {
            const response = await fetch(`${API_URL}/users/${user.id}/avatar`, {
                method: 'POST',
                body: uploadData,
            });
            
            if (response.ok) {
                const updatedProfile = await response.json();
                setProfile(updatedProfile);
                setMessage({ type: 'success', text: t.profile.avatarSuccess });
            } else {
                const errorData = await response.json().catch(() => ({}));
                console.error('Upload failed:', response.status, errorData);
                throw new Error(errorData.message || (t.profile.avatarError));
            }
        } catch (err: any) {
            console.error('Error uploading avatar:', err);
            setMessage({ type: 'error', text: err.message || t.profile.avatarError });
        } finally {
            setIsUploading(false);
        }
    };

    const handleProfileUpdate = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;

        setIsSaving(true);
        setMessage({ type: '', text: '' });
        try {
            await api.patch(`/users/${user.id}/profile`, formData);
            setMessage({ type: 'success', text: t.profile.savedSuccess });
            setTimeout(() => setMessage({ type: '', text: '' }), 3000);
        } catch (err) {
            console.error('Error updating profile:', err);
            setMessage({ type: 'error', text: t.profile.passwordError }); // Using a generic error key if profile specific one is missing, but savedError is not there. I'll use passwordError for now or assume I added one. Wait, I added savedSuccess but not savedError.
        } finally {
            setIsSaving(false);
        }
    };

    const handleChangePassword = async (e: React.FormEvent) => {
        e.preventDefault();
        if (!user) return;
        
        if (passwordData.newPassword !== passwordData.confirmPassword) {
            setPasswordMessage({ type: 'error', text: t.profile.passwordMismatch });
            return;
        }
        
        setIsChangingPassword(true);
        setPasswordMessage({ type: '', text: '' });
        
        try {
            await api.patch('/auth/change-password', {
                userId: user.id,
                currentPassword: passwordData.currentPassword,
                newPassword: passwordData.newPassword
            });
            setPasswordMessage({ type: 'success', text: t.profile.passwordSuccess });
            setPasswordData({ currentPassword: '', newPassword: '', confirmPassword: '' });
            setTimeout(() => setPasswordMessage({ type: '', text: '' }), 3000);
        } catch (err: any) {
            console.error('Error changing password:', err);
            setPasswordMessage({ type: 'error', text: err.message || t.profile.passwordError });
        } finally {
            setIsChangingPassword(false);
        }
    };

    const handleDeleteAddress = async (id: string) => {
        if (!confirm(t.profile.deleteAddressConfirm)) return;
        try {
            await api.delete(`/addresses/${id}`);
            setAddresses(prev => prev.filter(a => a.id !== id));
        } catch (err) {
            console.error('Error deleting address:', err);
        }
    };

    if (isLoading) {
        return (
            <div className="min-h-screen bg-background flex flex-col items-center justify-center">
                <Loader2 className="animate-spin text-primary mb-4" size={40} />
                <p className="text-[10px] font-black uppercase tracking-widest text-muted-foreground">{t.profile.loadingProfile}</p>
            </div>
        );
    }

    return (
        <div className="min-h-screen bg-[#f8f9fa] pb-20">
            <Navbar />

            <main className="max-w-4xl mx-auto px-4 py-12 animate-fade-in">
                <div className="grid grid-cols-1 lg:grid-cols-3 gap-8">
                    {/* Profile Card */}
                    <div className="lg:col-span-1 space-y-6">
                        <div className="bg-card rounded-[32px] border border-border overflow-hidden shadow-sm">
                            <div className="jhoanes-gradient p-8 text-white flex flex-col items-center">
                                <div 
                                    className="w-24 h-24 bg-white/20 rounded-full flex items-center justify-center border-4 border-white/30 mb-4 backdrop-blur-md overflow-hidden cursor-pointer relative group"
                                    onClick={() => document.getElementById('avatar-input')?.click()}
                                >
                                    {profile?.avatar_url ? (
                                        <img 
                                            src={profile.avatar_url?.startsWith('http') || profile.avatar_url?.startsWith('data:') ? profile.avatar_url : `${API_URL}${profile.avatar_url}`} 
                                            alt="Avatar" 
                                            className="w-full h-full object-cover"
                                        />
                                    ) : (
                                        <User size={48} />
                                    )}
                                    <div className="absolute inset-0 bg-black/40 flex items-center justify-center opacity-0 group-hover:opacity-100 transition-opacity">
                                        <Plus size={24} />
                                    </div>
                                    {isUploading && (
                                        <div className="absolute inset-0 bg-black/60 flex items-center justify-center">
                                            <Loader2 size={24} className="animate-spin" />
                                        </div>
                                    )}
                                </div>
                                <input 
                                    id="avatar-input"
                                    type="file"
                                    accept="image/*"
                                    className="hidden"
                                    onChange={handleAvatarUpload}
                                />
                                <h2 className="text-xl font-bold font-serif">{formData.full_name || (locale === 'en' ? 'User' : 'Usuario')}</h2>
                                <p className="text-white/70 text-[10px] font-black uppercase tracking-[0.2em] mt-1">{t.profile.memberClient}</p>
                            </div>
                            <div className="p-6 space-y-4">
                                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                    <Mail size={16} className="text-primary" />
                                    <span className="truncate">{user?.email}</span>
                                </div>
                                <div className="flex items-center gap-3 text-sm text-muted-foreground">
                                    <BadgeCheck size={16} className="text-primary" />
                                    <span>{t.profile.verifiedAccount}</span>
                                </div>
                            </div>
                        </div>

                        <button 
                            onClick={() => router.push('/profile/addresses/new')}
                            className="w-full premium-button bg-white text-primary border-2 border-primary/10 py-4 hover:bg-primary/5 shadow-none flex items-center justify-center gap-2 group"
                        >
                            <Plus size={18} className="group-hover:rotate-90 transition-transform" /> {t.profile.addAddress}
                        </button>
                    </div>

                    {/* Editor Section */}
                    <div className="lg:col-span-2 space-y-8">
                        {/* Profile Editor */}
                        <div className="bg-card rounded-[32px] border border-border p-8 shadow-sm">
                            <h3 className="text-xl font-bold font-serif mb-8 flex items-center gap-2">
                                <User className="text-primary" size={24} /> {t.profile.editInfo}
                            </h3>

                            <form onSubmit={handleProfileUpdate} className="space-y-6">
                                {message.text && (
                                    <div className={`p-4 rounded-2xl text-xs font-bold text-center animate-fade-in ${message.type === 'success' ? 'bg-green-50 text-green-600 border border-green-100' : 'bg-red-50 text-red-600 border border-red-100'}`}>
                                        {message.text}
                                    </div>
                                )}
                                
                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.fullName}</label>
                                        <input 
                                            type="text"
                                            className="premium-input px-6 h-14 font-bold"
                                            value={formData.full_name}
                                            onChange={(e) => setFormData({...formData, full_name: e.target.value})}
                                            required
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.username}</label>
                                        <input 
                                            type="text"
                                            className="premium-input px-6 h-14 font-bold"
                                            value={formData.username}
                                            onChange={(e) => setFormData({...formData, username: e.target.value})}
                                            required
                                        />
                                    </div>
                                </div>

                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.contactPhone}</label>
                                    <div className="relative">
                                        <input 
                                            type="tel"
                                            className="premium-input px-6 h-14 font-bold pl-12"
                                            value={formData.phone}
                                            onChange={(e) => setFormData({...formData, phone: e.target.value})}
                                            required
                                        />
                                        <Phone size={18} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground" />
                                    </div>
                                </div>

                                <button 
                                    disabled={isSaving}
                                    className="w-full premium-button jhoanes-gradient text-white py-4 shadow-xl flex items-center justify-center gap-2"
                                >
                                    {isSaving ? <Loader2 className="animate-spin" size={20} /> : <><Save size={20} /> {t.profile.save}</>}
                                </button>
                            </form>
                        </div>

                        {/* Saved Addresses */}
                        <div className="bg-card rounded-[32px] border border-border p-8 shadow-sm">
                            <h3 className="text-xl font-bold font-serif mb-8 flex items-center gap-2">
                                <MapPin className="text-primary" size={24} /> {t.profile.savedAddresses}
                            </h3>

                            <div className="space-y-4">
                                {addresses.length > 0 ? (
                                    addresses.map((addr) => (
                                        <div key={addr.id} className="p-6 bg-white border border-border rounded-2xl flex justify-between items-start hover:border-primary/30 hover:shadow-md transition-all group">
                                            <div className="flex gap-4">
                                                <div className="w-12 h-12 bg-primary/5 rounded-xl flex items-center justify-center text-primary group-hover:bg-primary group-hover:text-white transition-colors">
                                                    <MapPin size={20} />
                                                </div>
                                                <div>
                                                    <h4 className="font-black text-sm uppercase tracking-tight mb-1">{addr.alias}</h4>
                                                    <p className="text-xs text-muted-foreground leading-relaxed max-w-sm">{addr.address}</p>
                                                    <div className="mt-2 flex items-center gap-2">
                                                        <span className="text-[8px] font-black uppercase tracking-widest bg-secondary text-primary px-2 py-0.5 rounded-full">Zone {addr.zone}</span>
                                                        {addr.is_default && <span className="text-[8px] font-black uppercase tracking-widest bg-green-50 text-green-600 px-2 py-0.5 rounded-full border border-green-100">{locale === 'en' ? 'Default' : 'Predeterminada'}</span>}
                                                    </div>
                                                </div>
                                            </div>
                                            <button 
                                                onClick={() => handleDeleteAddress(addr.id)}
                                                className="p-2 text-muted-foreground hover:text-red-500 hover:bg-red-50 rounded-xl transition-all"
                                                title={t.common.delete}
                                            >
                                                <Trash2 size={18} />
                                            </button>
                                        </div>
                                    ))
                                ) : (
                                    <div className="py-12 text-center bg-muted/20 rounded-3xl border border-dashed border-border/40">
                                        <p className="text-sm text-muted-foreground">{t.profile.noAddresses}</p>
                                    </div>
                                )}
                            </div>
                        </div>

                        {/* Change Password Card */}
                        <div className="bg-card rounded-[32px] border border-border p-8 shadow-sm">
                            <h3 className="text-xl font-bold font-serif mb-8 flex items-center gap-2">
                                <Plus className="text-primary" size={24} /> {t.profile.security}
                            </h3>

                            <form onSubmit={handleChangePassword} className="space-y-6">
                                {passwordMessage.text && (
                                    <div className={`p-4 rounded-2xl text-xs font-bold text-center animate-fade-in ${passwordMessage.type === 'success' ? 'bg-green-50 text-green-600 border border-green-100' : 'bg-red-50 text-red-600 border border-red-100'}`}>
                                        {passwordMessage.text}
                                    </div>
                                )}

                                <div className="space-y-2">
                                    <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.currentPassword}</label>
                                    <input 
                                        type="password"
                                        className="premium-input px-6 h-14 font-bold"
                                        value={passwordData.currentPassword}
                                        onChange={(e) => setPasswordData({...passwordData, currentPassword: e.target.value})}
                                        required
                                    />
                                </div>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.newPassword}</label>
                                        <input 
                                            type="password"
                                            className="premium-input px-6 h-14 font-bold"
                                            value={passwordData.newPassword}
                                            onChange={(e) => setPasswordData({...passwordData, newPassword: e.target.value})}
                                            required
                                        />
                                    </div>
                                    <div className="space-y-2">
                                        <label className="text-[10px] font-black uppercase text-muted-foreground ml-2 tracking-widest">{t.profile.confirmPassword}</label>
                                        <input 
                                            type="password"
                                            className="premium-input px-6 h-14 font-bold"
                                            value={passwordData.confirmPassword}
                                            onChange={(e) => setPasswordData({...passwordData, confirmPassword: e.target.value})}
                                            required
                                        />
                                    </div>
                                </div>

                                <button 
                                    disabled={isChangingPassword}
                                    className="w-full premium-button bg-black text-white py-4 shadow-xl flex items-center justify-center gap-2"
                                >
                                    {isChangingPassword ? <Loader2 className="animate-spin" size={20} /> : <>{t.profile.updatePassword}</>}
                                </button>
                            </form>
                        </div>
                    </div>
                </div>
            </main>
        </div>
    );
}
